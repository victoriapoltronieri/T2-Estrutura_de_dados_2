#ifndef SEARCH_H
#define SEARCH_H

void search(Suffix **suf, int context, int lgt, char *key);

#endif